import React from "react";
import Layout from "../components/layout/Layout";
import { Box, Typography } from "@mui/material";

const About = () => {
  return (
    <Layout>
      <Box
        sx={{
          my: 15,
          textAlign: "center",
          p: 2,
          "& h4": { fontWeight: "bold", my: 2, fontSize: "2rem" },
          "& p": {
            textAlign: "justify",
          },
          "@media(max-width:600px)": {
            mt: 0,
            "& h4": {
              fontSize: "1.5rem",
            },
          },
        }}
      >
        <Typography variant="h4">Welcome to HYK Restuarant</Typography>
        <p>
          HYK Restuarant is Christian Restuarant at UCU which is a branch of HYK
          Hotels international. It was started by Group5 we prgramming in
          partnership with Odonkara Oscar and UCU University community. HYK
          Restuarant main branch is Inside UCU but it hs several outlets at
          Bugujju, Kauga and all other parts of Mukono and Kampala. The
          Restuarant was started inorder to help lecturers, students and the
          community to get food delivery whereever they are without moving.
        </p>
        <p>
          HYK Restuarant provides many services such as outside catering, at
          Restuarant sale and on door delivery. Our services are availabe 24
          hours a day and 7 days a week. Henc you catering make your order at
          any time in any plac. HYK also works hand-in-hand ith Dembe roller
          using our coordinators as Mukama, Benja Nickson.
        </p>
        <br />
        <p>
          HYK Restuarant has a lot of suppliers which makes it the leading
          center of providing side jobs to lecturers, students the communities
          and all other parts in the country where we have branches. We provide
          jobs to over 100 workers at our Restuarant ranging from Chiefs,
          delivery service providers waitresses, accountanta, marketiers and
          many more. We have world class proffessional staff. We have also
          technologised our services by using drawns to deliver orders to our
          customers. This helps to reduce on delays caused by jam and road
          interferences.
        </p>
      </Box>
    </Layout>
  );
};
export default About;
