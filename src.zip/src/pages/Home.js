import React from "react";
import Layout from "../components/layout/Layout";
import { Link } from "react-router-dom";
import Emma from "../components/images/Emma.png";
import "../styles/HomeStyle.css";

const Home = () => {
  return (
    <Layout>
      <div className="home" style={{ backgroundImage: `url(${Emma})` }}>
        <div className="headerContainer">
          <h1>HYK Restuarant</h1>
          <p>We Provide The Best Food In UCU</p>
          <p>Delivery Done At Your Hostel Or Office</p>
          <Link to="/menu">
            <button>ORDER NOW</button>
          </Link>
        </div>
      </div>
    </Layout>
  );
};
export default Home;
