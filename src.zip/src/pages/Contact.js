import React from "react";
import Layout from "../components/layout/Layout";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import EmailIcon from "@mui/icons-material/Email";
import SupportAgentIcon from "@mui/icons-material/SupportAgent";

import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";

const Contact = () => {
  return (
    <Layout>
      <Box sx={{ my: 10, ml: 10, "& h4": { fontweight: "bold", mb: 2 } }}>
        <Typography variant="h4">Contact Our Restuarant</Typography>
        <p>
          HYK Restuarant is located inside Uganda Christian University at
          opposit Florence Mirembe Hall with several around Bugujju, Techpark
          and several branches around compus. You can follow our our twitter
          handle, Instagram, Facebook. You can also contact us using the
          contacts below.
        </p>
      </Box>
      <Box
        sx={{
          m: 5,
          width: "600px",
          ml: 10,
          "@media (max-width:600px)": {
            width: "300px",
          },
        }}
      >
        <TableContainer component={Paper}>
          <Table aria-label="contact table">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{ bgcolor: "black", color: "white" }}
                  align="center"
                >
                  Contact Details
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell>
                  <LocalPhoneIcon sx={{ color: "green", pt: 1 }} />
                  +256764616216/+256703082013
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>
                  <EmailIcon sx={{ color: "skyblue", pt: 1 }} />
                  HYKucu@gmail.ucu.ug.com
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>
                  <SupportAgentIcon sx={{ color: "red", pt: 1 }} />
                  +0334946387(tollfree)
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </Layout>
  );
};
export default Contact;
