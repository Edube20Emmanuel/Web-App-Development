import Chola from "../components/images/chhola.png";
import Dosa from "../components/images/dosa.png";
import Gujrati from "../components/images/gujrati.png";
import MasalaDosa from "../components/images/masala.png";
import Paneer from "../components/images/paneer.png";
import Idli from "../components/images/idli.png";
import Masala from "../components/images/masala.png";

//import React from "react";

export const MenuList = [
  {
    name: "Chola",
    description:
      "The most cheap but delicious meal served with tomatoes and lemon",
    image: Chola,
    price: 6500,
  },
  {
    name: "Lusania",
    description: "Contains a variety of local soop and food",
    image: Gujrati,
    price: 8000,
  },
  {
    name: "MasalaDosa",
    description:
      "This is our other delicious food if you test you not fail to ask for more.",
    image: MasalaDosa,
    price: 10000,
  },
  {
    name: "Katogo",
    description: "This is our delicious dish for local people.",
    image: Paneer,
    price: 7500,
  },
  {
    name: "Moon Mandazi",
    description: "This comes with round rice balls and a dish of soop.",
    image: Idli,
    price: 300,
  },
  {
    name: "Masala",
    description:
      "It contains chapati, tomato suace dish and a variety of other dishes and diserts.",
    image: Masala,
    price: 100,
  },
  {
    name: "Dembe Roller",
    description: "This comes with soop dishes to spice up the entire meal.",
    image: Dosa,
    price: 6000,
  },
];
